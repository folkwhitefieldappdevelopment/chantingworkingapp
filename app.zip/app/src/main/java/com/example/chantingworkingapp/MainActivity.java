package com.example.chantingworkingapp;
import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.Vibrator;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chantingworkingapp.history.model.ChantingDailyDataEntity;
import com.example.chantingworkingapp.history.model.ChantingRoundDataEntity;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Firebase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import java.lang.reflect.Type;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

import com.google.android.material.navigation.NavigationView;


public class MainActivity extends AppCompatActivity {
    TextView startButtonTextView,textView,ticktext, goldenview,hkmview, round_score, chanting_text, hearing_text, speed_text, bead_text, table_tt, table_th;
    // table textview
    ImageView imageview,help,tickview, startimg,reset,stop;
    int hearingCount = 0, round = 1, totalround = 0,prog_pos = -1,prog_pos2 =-1,hearprogress = 0;
    private int popup = 0,progressStatus = 0,seconds, minutes, milliSeconds, maxCount = 16,normalizedProgress,value = 2;
    private boolean stopwatchRunning = false, exitapp = false,isSameDay, dataloaded = false;
    volatile int stopResetPressed = 0, hkm = 0;
    FirebaseAuth auth;
    private static final int[]  chantingProgressBar = { R.id.prog16
            ,R.id.prog32
            ,R.id.prog48
            ,R.id.prog64
            ,R.id.prog80
            ,R.id.prog96
            ,R.id.prog108

    };
    private static final int[]  hearingProgressBar  = { R.id.secondprog16
            ,R.id.secondprog32
            ,R.id.secondprog48
            ,R.id.secondprog64
            ,R.id.secondprog80
            ,R.id.secondprog96
            ,R.id.secondprog108

    };
    private TextView[] chantBar = new TextView[chantingProgressBar.length];
    private TextView[] hearBar = new TextView[hearingProgressBar.length];
    FirebaseDatabase database;
    private FirebaseUser firebaseUser;

    long millisecondTime, totaltimemillis = 0,startTime,timeBuff, endTime, executionTime,updateTime = 0L,totalSeconds = 0;
    private ProgressBar horizontalProgressBar,horizontalProgressBar2;
    private Handler handler;
    CustomDialog customDialog;
    String userInput;
    HistoryActivity history;
    private Button hear_button,start;
    private Date start_time, totaltime;
    private float playbackSpeed = 1.0f;
    private String current_time,text, table_tt_time, resultTimeString, total_time = "00:00";
    private int spChantingCount = -1, total_heard;
    private MediaPlayer mediaPlayer, mediaPlayerMalaCountBreakageAlert, mediaPlayer108, mediaPlayerhkm;
    private Spinner playbackSpeedSpinner, add_spinner;
    private ArrayAdapter<CharSequence> playbackSpeedAdapter, add_spinnerAdapter;
    private float[] playbackSpeedValues = { 0.75f,1.0f, 1.15f, 1.5f};
    private int[] addSpinner = {5,4,3,2};

    public static final String SHARED_PREFS = "sharedPrefs";
    public static String TEXT = "text";
    ArrayList<ModelClass> arrayList;
    private ProgressBar[] prog_bar = new ProgressBar[7];
    private ProgressBar[] prog_bar2 = new ProgressBar[7];
    DrawerLayout draw ;
    NavigationView nav ;
    ActionBarDrawerToggle action;
    private String[] videoIds = {
//            "zEtAgUtXvRU",
//            "SUbhkUd8c68",
//            "QnLevMrkQ_0",
//            "t--PFs-xxo4",
//            "m3QkR8qBgw8",
//            "6Fl0bGCVPCY",
//            "-csUVDrYhPg",
//            "nD_JQMmov8o",
//            "BMzyCEM5f8E"

            "MF-k_a9u5RU"
    };
    TextView show;
    private String[] goldenCommmands={
            "Chant distinctly and hear clearly.",
            "You don't have to do any separate concentration to hear; you simply hear.",
            "Chanting, hearing, and without any thinking, you should go to the next bead, chant, and hear.",
            "Chant and hear and no thinking.",
            "Not simply chant, chant, chant, chant, no chant and hear, chant and hear.",
            "No thinking, chanting hearing, chanting hearing, chanting hearing.",
            "Chant consciously and hear consciously.",
            "You chant and hear the same sound; already 90 percent soulful japa.",
            "Our slow progress in Japa all these years was only because of thinking Japa; now you replace it with hearing Japa.",
            "Hear every Maha mantra; every hearing is like an attention embrace.",
            "The mind will become completely purified. The more you hear, the more you become purified.",
            "Hearing is not concentration; don't unnecessarily strain your mind. Hearing means simple hearing, or.",
            "Hear the whole mantra; don't strain in the beginning to hear word by word; automatically, concentration will come.",
            "As you chant, you hear, and then you can never think.",
            "Hear the full mantra as a single sound.",
            "Helplessly chant with simultaneous hearing.",
            "Chant do nothing else; hear nothing else.",
            "Chanting, hearing, and not thinking If you think you cannot hear, you can do only one thing: either think or hear.",
            "No hearing means no association with the Lord; only your tongue gets association.",
            "No separate concentration is required; hear concentration will follow, called hearing yoga.",
            "Don't even think I should hear what I should hear is not hearing; that is thinking instead of simply hearing.",
            "Push out the thinking with hearing. Any time thinking comes, push it out with hearing.",
            "Chant and hear your own chant.",
            "Change your thinking japa to hearing japa, once for all goodbye to thinking japa.",
            "Chanting and hearing Japa: Hearing Japa means big success.",
            "As soon as it comes again, hear immediately; the sound will push out thinking.",
            "Chant and hear carefully, respectfully, and soulfully.",
            "Thinking is the biggest enemy during Japa; you should hear instead of thinking.",
            "Your slogan should be Chanting Hearing, Chanting Hearing.",
            "Intention is to lock the attention chant and hear that very same sound.",
            "Simply hear that nama and touch me and sit down, and I will flow into your heart.",
            "If the mind goes away again, hear the mind go again, hear.",
            "My as soon as one hearing is over, the next hearing piles up one hearing over another hearing, one hearing over another hearing.",
            "Hear without leaving one sound that you chant the full Maha mantra.",
            "Chanting, hearing, no thinking; hearing is drinking Krishna through the hears.",
            "Chanting hearing, no thinking; thinking means you are not hearing.",
            "Don't think, if your mind has to experience higher taste You have to hear.",
            "Don't foolishly try to control attention directly; you cannot. Chant hear.",
            "Chant Hear no thinking, Hearing Japa gives you energy; thinking Japa drains your mind energy.",
            "Don't think, how much you advance in 100 years of thinking Japa. In one year, you can advance by hearing Japa.",
            "Chant hear, chant hear, don't think; if you don't hear, you will think.",
            "No thinking.",
            "Hearing means simple hearing. Don't confuse it with concentrations.",
            "Chanting is welcoming and hearing is embracing; welcoming the nama avatara and hearing the nama avatara.",
            "For each bead, I offer fresh hearing by knowing the sound.",
            "As you chant immediately hear, right at the throat level itself, you hear.",
            "Chant and hear every bead.",
            "No thinking, chanting, and hearing.",
            "Chanting, hearing, no thinking, thinking is a big enemy for Japa.",
            "Thinking about Japa is tiring; hearing about Japa is energizing.",
            "Don't think. You have 22 hours to think. Tell your mind. Please allow me to hear, all your thinking you can do after I finish Japa.",
            "Hearing Japa makes you want to chant more and more; thinking Japa makes you feel when can I finish?",
            "Chanting, hearing, and begging Nama Prabhu.",
            "Chanting and hearing, with no thinking, no dreaming, or no worrying.",
            "Thinking means going into the past and going into the future. You have to be here and now.",
            "Your life is successful if you learn to hear Japa.",
            "Chanting is making the sound; hearing is knowing that you chant; hearing is not doing; don't struggle to do something to hear.",
            "Please nama prabhu more and more by chanting and hearing.",
            "Hear and exactly the same sound you hear this is a secret.",
            "You hear that will cut off thinking.",
            "Thinking consumes our attention and we will not have attention for hearing. Chanting hearing.",
            "Delightfully chant joyfully here.",
            "If you think you cannot hear, if you hear, you cannot think. So we have to replace every urge to think with hearing.",
            "Don't try to control our mind; try to control the process called hearing.",
            "I should chant and hear that very sound. Ignore the mind.",
            "No thinking of anything, only chanting and hearing.",
            "Hearing means like an attention embrace.",
            "Hearing is like taking the medicine to cure our hearts.",
            "Hearing is like the tonic for the souls.",
            "The mind can do only one thing: either hear or think. If you think you're not hearing, you're not hearing.",
            "One hearing over another hearing, one hearing over another hearing, no time to think.",
            "Every chanting and hearing one step closer to Krishna.",
            "Lock the attention chanting hearing, chanting hearing.",
            "Chant hear big service, big freedom from Maya services.",
            "If you lock your attention on the sound and stop thinking your japa is successful.",
            "Chanting hearing gives energetic japa; chanting thinking is tiresome japa.",
            "Do not engage the mind in thinking helplessly; chant and eagerly hear.",
            "No thought processing during Japa.",
            "Chant and exactly the same sound you hear.",
            "Chant and send the Nama inside one after the other.",
            "Any time hearing goes away, bring back the hearing again, chant, and hear.",
            "Whatever you chant, you should hear it.",
            "While you chant, you hear.",
            "As soon as you chant, try to hear.",
            "Chant with full attention, here and now.",
            "Engage fully in chanting, hearing, and repeating.",
            "Stay focused and determined.",
            "Consciously chant each bead with full awareness.",
            "Focus completely on chanting in the present moment.",
            "Keep bringing your focus back to the chant whenever it wanders.",
            "Engage fully in chanting, hearing, and repeating the name.",
            "The process is that you chant Hare Krishna, and exactly the same sound is heard.",
            "You simply hear. When you say, “Hare Krishna,” you try to hear the very sound.",
            "As you chant, try to hear each word very carefully.",
            "This is very important. When you chant, you'll hear it.",
            "You simply chant Hare Krishna and try to hear the sound; that’s all.",
            "When you chant, you must also hear.",
            "While chanting, you must hear. Hare Krishna, you must pay attention to what you hear.",
            "“Hare Krishna” should be very distinctly pronounced and heard.",
            "One should simply chant the holy name of God sincerely and hear it with attention.",
            "Chanting and hearing, locked up. The mind is locked up.",
            "As soon as you chant Hare Krishna, you hear it, and then your mind becomes locked up."

    };
    private String[] namaPrabhuStatements = {
            "I am drinking Nama Prabhu",
            "I love Nama Prabhu",
            "I am embracing Nama Prabhu",
            "I am hearing Nama Prabhu",
            "I soulfully chant Nama Prabhu",
            "I am addicted to Nama Prabhu",
            "I am Nama sevaka",
            "I am Nama premi",
            "I am Nama Sadhaka",
            "I am greedy for Nama Prabhu",
            "I will not leave Nama Prabhu",
            "I trust Nama Prabhu",
            "My only hope is Nama Prabhu",
            "Nama is only my life and soul"
    };
    FirebaseUser user;

    //stopwatch running code
    private Handler stopwatchHandler;
    private PowerManager.WakeLock wakeLock;
    TextView prog16,prog32,prog48,prog64,prog80,prog96,prog108,sprog16,sprog32,sprog48,sprog64,sprog80,sprog96,sprog108;
    ImageView mute,unmute;
    private ChantingRoundDataEntity chantingRoundDataEntity;
//    String[]



    // on create function code
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast toast = new Toast(getApplicationContext());
        //Firebase Authentication
        auth = FirebaseAuth.getInstance();
        firebaseUser = auth.getCurrentUser();
        database=FirebaseDatabase.getInstance();
        user  = auth.getCurrentUser();

        //drawer layout Initalization
        draw = findViewById(R.id.drawer_layout);
        nav = findViewById(R.id.nav_view);
        nav.bringToFront();
        action = new ActionBarDrawerToggle(this,draw,R.string.navigation_open,R.string.navigation_close);
        draw.addDrawerListener(action);
        action.syncState();
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                return drawermenunavigation(item);
            }
        });
        // Initialized each Progress bar TextView
        chantBar[0] = findViewById(chantingProgressBar[0]);
        chantBar[1] = findViewById(chantingProgressBar[1]);
        chantBar[2] = findViewById(chantingProgressBar[2]);
        chantBar[3] = findViewById(chantingProgressBar[3]);
        chantBar[4] = findViewById(chantingProgressBar[4]);
        chantBar[5] = findViewById(chantingProgressBar[5]);
        chantBar[6] = findViewById(chantingProgressBar[6]);
        hearBar[0]  = findViewById(hearingProgressBar[0]);
        hearBar[1]  = findViewById(hearingProgressBar[1]);
        hearBar[2]  = findViewById(hearingProgressBar[2]);
        hearBar[3]  = findViewById(hearingProgressBar[3]);
        hearBar[4]  = findViewById(hearingProgressBar[4]);
        hearBar[5]  = findViewById(hearingProgressBar[5]);
        hearBar[6]  =  findViewById(hearingProgressBar[6]);

        // Initialization and working of sound  layout
        mute = findViewById(R.id.mute);
        unmute=findViewById(R.id.unmute);
        mute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Assuming mediaPlayer is your instance of MediaPlayer
                mediaPlayer.setVolume(0.0f, 0.0f);
                unmute.setVisibility(View.VISIBLE);
                mute.setVisibility(View.INVISIBLE);// Set both left and right channel volumes to 0.0f
            }
        });
        unmute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Assuming mediaPlayer is your instance of MediaPlayer
                mediaPlayer.setVolume(1.0f, 1.0f);
                mute.setVisibility(View.VISIBLE);
                unmute.setVisibility(View.INVISIBLE);// Set both left and right channel volumes to 0.0f
            }
        });

        imageview = findViewById(R.id.SpImage);
        tickview = findViewById(R.id.rounddone);
        imageview.setImageResource(R.drawable.srila_prabhupada);
        help = findViewById(R.id.hamburgerIcon);
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the navigation
                vibrate(50);
                draw.setVisibility(View.VISIBLE);
                draw.getOverlay();
                draw.openDrawer(GravityCompat.START);
            }
        });
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK, "MyApp::WakeLockTag");
        wakeLock.acquire();
        //prohgressbar

        // Initialized each Progress bar
        history = new HistoryActivity();
        horizontalProgressBar = findViewById(R.id.vprogressBar);
        prog_bar[0] = findViewById(R.id.vprogressBar);
        prog_bar[1] = findViewById(R.id.vprogressBar2);
        prog_bar[2] = findViewById(R.id.vprogressBar3);
        prog_bar[3] = findViewById(R.id.vprogressBar4);
        prog_bar[4] = findViewById(R.id.vprogressBar5);
        prog_bar[5] = findViewById(R.id.vprogressBar6);
        prog_bar[6] = findViewById(R.id.vprogressBar7);

        horizontalProgressBar2 = findViewById(R.id.progressBar);
        prog_bar2[0] = findViewById(R.id.progressBar);
        prog_bar2[1] = findViewById(R.id.progressBar2);
        prog_bar2[2] = findViewById(R.id.progressBar3);
        prog_bar2[3] = findViewById(R.id.progressBar4);
        prog_bar2[4] = findViewById(R.id.progressBar5);
        prog_bar2[5] = findViewById(R.id.progressBar6);
        prog_bar2[6] = findViewById(R.id.progressBar7);
        //music  of layout
        mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.sp_hkm);
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                // Prepare MediaPlayer to play the audio file again
                mediaPlayer.seekTo(0);

            }
        });
        stopwatchHandler = new Handler(Looper.getMainLooper());
        mediaPlayerMalaCountBreakageAlert = MediaPlayer.create(MainActivity.this, R.raw.beat16);
        mediaPlayer108 = MediaPlayer.create(MainActivity.this, R.raw.beat108);
        mediaPlayerhkm = MediaPlayer.create(MainActivity.this, R.raw.hkm);

        //custom dialog creation



        // textview of layout
        ticktext = findViewById(R.id.rounddonetext);
        textView = findViewById(R.id.timetext);
        hkmview = findViewById(R.id.HKM);
        goldenview= findViewById(R.id.goldencommand);
        chanting_text = findViewById(R.id.chanting_text);
        hearing_text = findViewById(R.id.Hearing_text);
        bead_text = findViewById(R.id.Bead_text);
        round_score = findViewById(R.id.rounds_text);
        //Buttons of layout
        reset = findViewById(R.id.resetbutton);
        start = findViewById(R.id.start);
        startimg = findViewById(R.id.startbutton);
        stop = findViewById(R.id.stopbutton);
        hear_button = (Button) findViewById(R.id.hear);

        //dropdown of layout
        add_spinner = findViewById(R.id.addingspiner);
//        playbackSpeedSpinner = findViewById(R.id.playbackSpeedSpinner);
        handler = new Handler(Looper.getMainLooper());
        add_spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.adding, android.R.layout.simple_spinner_item);
        add_spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        add_spinner.setAdapter(add_spinnerAdapter);

        add_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                value = addSpinner[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing
            }
        });
        customDialog = new CustomDialog(this);

        hear_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inflate custom layout

                int lowerLimit = 0;
                int upperLimit = 13;
                List<Integer> used = new ArrayList<>();
//
                int randomNumber = generateRandomNumber(lowerLimit, upperLimit,used);
                View layout = getLayoutInflater().inflate(R.layout.custom_toast,
                        (ViewGroup) findViewById(R.id.custom_toast_layout));

                // Set your custom message
                TextView textHearQuote = layout.findViewById(R.id.text);

                textHearQuote.setText(String.valueOf(namaPrabhuStatements[randomNumber]));

                // Create and show the custom Toast
                toast.setGravity(Gravity.START | Gravity.CENTER, 1100, 400);
                toast.setDuration(Toast.LENGTH_SHORT);
                toast.setView(layout);
                vibrate(100);
                toast.show();

                if (hearingCount >=96 && hearingCount <= 108) {
                    maxCount = 12;
                }
                int minus = value;
                while(minus!=0) {
                    if (hearingCount % 16 == 0 && prog_pos2 != 7 && hearingCount <= 107) {
                        // Inside your MainActivity
                        hearprogress = 0;
                        prog_pos2++;
                        horizontalProgressBar2 = prog_bar2[prog_pos2];
                    }
                    hearingCount +=1;
                    minus -= 1;
                }
                hearprogress += value;
                int hearnormalizedProgress= (int) ((hearprogress / (float) maxCount) * 100);
                horizontalProgressBar2.setSecondaryProgress(hearnormalizedProgress);
                hear_button.setText(String.valueOf(hearingCount));

                if (hearingCount >= 107) {
                    hear_button.setText(String.valueOf(0));
                    hearingCount = 0;
                    prog_pos2 = -1;
                    for(int i = 0; i<7;i++){
                        prog_bar2[i].setSecondaryProgress(0);
                    }
                }

            }
        });


//        playbackSpeedAdapter = ArrayAdapter.createFromResource(this, R.array.playback_speed_options, android.R.layout.simple_spinner_item);
//        playbackSpeedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        playbackSpeedSpinner.setAdapter(playbackSpeedAdapter);
//        playbackSpeedSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
//                playbackSpeed = playbackSpeedValues[position];
//                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parentView) {
////                // Do nothing
////                mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(1.0f));
//            }
//        });
//        playbackSpeedSpinner.setSelection(1);

        textView.setText("00:00");
        loadData();

    }
    int menuopened = 1;
    int menuback = 0;



    @Override
    protected void onResume() {
        super.onResume();
        // Add your code here to resume any operations or update UI elements
    }
    private boolean drawermenunavigation(MenuItem item){
        int id = item.getItemId();

        if (id == R.id.home ) {
//                     Handle history option
            Intent intent = new Intent(MainActivity.this, Secondscreenlevelchose.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.history) {
//                     Handle history option
            Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.menu_speed) {
            showCustomDialog(MainActivity.this);
            // Handle speed option
            return true;
        } else if (id == R.id.menu_help) {

            showHelpDialog(MainActivity.this);
//                    Toast.makeText(MainActivity.this,"helppp",Toast.LENGTH_SHORT).show();
            // Handle help option
            return true;
        } else if (id == R.id.menu_quotes) {
            // Handle quotes option
            return true;
        } else if (id == R.id.menu_hearing) {
            // Handle hearing option
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        if(draw.isDrawerOpen(GravityCompat.START)){
            draw.closeDrawer(GravityCompat.START);

        } else {


            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setTitle("Exit App");
            builder.setMessage("Do you want to close the app?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (wakeLock != null && wakeLock.isHeld()) {
                        wakeLock.release();
                    }
                    FirebaseUser user  = auth.getCurrentUser();
                    ReadWriteContactDetails read = new ReadWriteContactDetails();
                    read.name = user.getDisplayName();
                    read.time = textView.getText().toString();
                    database.getReference().child("users").child(user.getUid()).setValue(read).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(getApplicationContext(), "L in Now", Toast.LENGTH_SHORT).show();

                        }
                    });
                    mediaPlayer.release();
                    finishAffinity();
                    mediaPlayer.release();
                    exitapp = true;
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }



    public void saveData(String time, String heard, long currenttime) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong("lastSaveTimestamp", currenttime);
        Gson gson = new Gson();
        arrayList.add(new ModelClass(time, Integer.parseInt(heard)));
        String json = gson.toJson(arrayList);
        editor.putString("table data", json);

        editor.apply();


    }
    YouTubePlayerView youTubePlayerView;
    public void showVideoPopup(View view) {
        // Create a Dialog with a custom layout
        Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);

        // Inflate the custom layout for the popup
        View popupView = getLayoutInflater().inflate(R.layout.popup_layout, null);

        // Set the custom layout for the dialog
        dialog.setContentView(popupView);

        // Find the YouTubePlayerView in the custom layout
        youTubePlayerView = popupView.findViewById(R.id.youtube_player_view);
        getLifecycle().addObserver(youTubePlayerView);

        youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                // Load and play the video
                youTubePlayer.loadVideo(String.valueOf(videoIds[0]), 0);
                youTubePlayer.play();// Enter fullscreen mode
            }
        });

        // Show the dialog
        dialog.show();
    }



    private int partition = 0;
    public void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        Gson gson = new Gson();
        dataloaded = true;
        String json = sharedPreferences.getString("table data", null);
        Type type = new TypeToken<ArrayList<ModelClass>>() {
        }.getType();

        long storedTimestamp = sharedPreferences.getLong("lastSaveTimestamp", 0);
        // Retrieve timestamp from stored data
        long currentTimestamp = System.currentTimeMillis();

        // Compare dates (ignoring time)
        isSameDay = android.text.format.DateUtils.isToday(storedTimestamp);


        arrayList = gson.fromJson(json, type);
        text = sharedPreferences.getString(TEXT, "Round 1");

        if (!isSameDay) {
            // Delete the data or perform necessary actions
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();  // Clear all data or specify the data to be deleted
            editor.apply();
        } else {
        }
        if (arrayList == null) {
            arrayList = new ArrayList<>();
        } else {
            round = history.loadtable(MainActivity.this,arrayList,partition);
            round_score.setText(String.valueOf("Round"+ String.valueOf(round + 1)));
        }
    }



    private int elsec = 0;
    private int waittime = 0;
    private final Runnable update_Runnable = new Runnable() {

        @Override
        public void run() {
            startButtonTextView = findViewById(R.id.start);
            if (stopResetPressed == 1) {
                handler.removeCallbacks(update_Runnable);
            }
            if(spChantingCount %16==0 && spChantingCount != 108 ) {
                mediaPlayerMalaCountBreakageAlert.start();
                progressStatus = 0;
                if(spChantingCount !=0) {
                    customDialog.show();
                    add_spinner.performClick();
                }
                prog_pos++;

                horizontalProgressBar= prog_bar[prog_pos];
            }
            if(spChantingCount %8 == 0) {
                List<Integer> usednum = new ArrayList<>();
                int randomNumber = generateRandomNumber(0, 101,usednum);
                goldenview.setText(String.valueOf(goldenCommmands[randomNumber]));
                goldenview.setVisibility(View.VISIBLE);
            }
            if (spChantingCount >=96 && spChantingCount <= 108) {
                maxCount = 12;
            }
            else {
                maxCount = 16;
            }
            if (spChantingCount == -1 && stopwatchRunning && exitapp == false) {
                startButtonTextView.setText("0");
                stopResetPressed = 0;
                Log.i(TAG, "Thread Name 3: " + Thread.currentThread().getName());

                mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(playbackSpeed));
                mediaPlayer.start();

//                    if(elsec ==1){
//                        prog_pos--;
//                        horizontalProgressBar= prog_bar[prog_pos];
//                        elsec = 0;
//                    }
//                    progressStatus += 1;
//                    normalizedProgress= (int) ((progressStatus / (float) maxCount) * 100);
//                horizontalProgressBar.setSecondaryProgress(normalizedProgress);
                spChantingCount++;
                handler.postDelayed(this, (long) (waittime / playbackSpeed));
                waittime = 4030;

            }
            // Check conditions for executing the code
            else if (spChantingCount < 108 && stopwatchRunning && exitapp == false) {
                waittime = 4030;
                handler.postDelayed(this, (long) (waittime / playbackSpeed));
                // Set playback parameters and start the media player
                mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(playbackSpeed));
                mediaPlayer.start();
                stopResetPressed = 0;
                spChantingCount++;
                startButtonTextView.setText(String.valueOf(spChantingCount));
                Log.d(TAG, "Inside Runnable");
                Log.d(TAG, "startButtonTextCount " + spChantingCount);
                progressStatus += 1;
                normalizedProgress = (int) ((progressStatus / (float) maxCount) * 100);
                horizontalProgressBar.setProgress(normalizedProgress);

                // Use a handler to delay the execution of the code inside the runnable

            }
            else if (spChantingCount >= 108) {
//                Log.i(TAG, "Thread Name 3 2: " + Thread.currentThread().getName());
//                Log.i(TAG, "Thread Name 3 3: " + Thread.currentThread().getName());

                TEXT ="Roūnd" +String.valueOf(round);
                TextView timetext = findViewById(R.id.timetext);
                for(int i = 0; i<7;i++){
                    prog_bar[i].setProgress(0);
                    prog_bar2[i].setSecondaryProgress(0);
                }

                if(round%4 == 0){
                    partition =1;
                }

                elsec = 1;
                prog_pos = -1;
                prog_pos2 = -1;
                progressStatus = 0;

                horizontalProgressBar2 = prog_bar2[0];
                horizontalProgressBar = prog_bar[0];
                hearprogress = 0;
//                Log.i(TAG, "Thread Name 3 4: " + Thread.currentThread().getName());
                int s = round + 1;
                round_score.setText(String.valueOf("Round " + s));
                goldenview.setVisibility(View.INVISIBLE);
                mediaPlayer.release();
//                Log.i(TAG, "Thread Name 3 5: " + Thread.currentThread().getName());
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.sp_hkm);
                popup = 1;
                reset.performClick();
                round++;
                stopResetPressed = 1;
                hear_button.setText(String.valueOf(0));
                spChantingCount = -1;
//                Log.i(TAG, "Thread Name 3 6: " + Thread.currentThread().getName());
                start.setText(String.valueOf("0"));
//                Log.i(TAG, "Thread Name 3 1: " + Thread.currentThread().getName());
                handler.post(this);

                String uid = UUID.randomUUID().toString();

                ChantingDailyDataEntity chantingDailyDataEntity = null;

                if (round == 1) {
                    Date currentDate = new Date();
                    chantingDailyDataEntity = new ChantingDailyDataEntity();
                    chantingDailyDataEntity.setUserId(user.getUid());
                    chantingDailyDataEntity.setRowId(user.getUid() + ":" +new SimpleDateFormat("dd-mm-yyyy").format(currentDate));
                    chantingDailyDataEntity.setChantingDate(currentDate);
                    chantingDailyDataEntity.setNumberOfRoundsDone(round-1);
                    chantingDailyDataEntity.setChantingRoundDataEntities(new ArrayList<>());
                } else {
                    chantingDailyDataEntity = database.getReference("chantingDailyDataEntity").child(user.getUid() + ":" +new SimpleDateFormat("dd-mm-yyyy").format(currentDate)).get().getResult().getValue(ChantingDailyDataEntity.class);
                }

                chantingDailyDataEntity.getChantingRoundDataEntities().add(chantingRoundDataEntity);

                database.getReference("chantingDailyDataEntity").child(user.getUid() + ":" +new SimpleDateFormat("dd-mm-yyyy").format(currentDate));

                database.getReference().child("Table history").child(user.getUid()).child(uid).setValue(table).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "L in Now", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }

        // Continue with a 4-second delay


    };


    public static String secondsToTimeString(long seconds) {
        long minutes = seconds / 60;
        long remainingSeconds = seconds % 60;

//        Toast.makeText(MainActivity.this, "Data Loaded "+String.format("%02d:%02d", minutes, remainingSeconds), Toast.LENGTH_SHORT).show();
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, remainingSeconds);
    }
    public TextView createTextView(Context context) {
        TextView textView = new TextView(context);



        // Set text color to white
        textView.setTextColor(getResources().getColor(android.R.color.white));

//         Set font family to Arial
        Typeface customFont = ResourcesCompat.getFont(this, R.font.lexiereadablebold);
        textView.setTypeface(customFont);

        // Set gravity to center horizontal
        textView.setGravity(Gravity.CENTER_HORIZONTAL);

        // Set padding in dp
        int paddingInDp = 2;
        float scale = getResources().getDisplayMetrics().density;
        int paddingInPx = (int) (paddingInDp * scale + 0.5f);
        textView.setPadding(paddingInPx, paddingInPx, paddingInPx, paddingInPx);

        return textView;
    }


    private void updateStartButtonText() {
        waittime = 4030;
        handler.post(update_Runnable);
//        Thread thread1 = new Thread(update_Runnable);
//        thread1.start();
    }

    public void stopbutton(View view) {
        startimg.setVisibility(View.VISIBLE);
        vibrate(50);
        stop.setVisibility(View.INVISIBLE);
        timeBuff += millisecondTime;
        stopwatchHandler.removeCallbacks(runnable_stopwatch);
        if (mediaPlayer.getCurrentPosition() < 6435) {
            mediaPlayer.pause();
            mediaPlayer.seekTo(0);
            handler.removeCallbacks(runnable_pacnhtattva);
        } else {
            hkm = 1;
            mediaPlayer.release();
            mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.hkm);
            handler.removeCallbacks(update_Runnable);
//            handler.removeCallbacks(run);

            Log.e("MainActivity", "Successfully hkm started MediaPlayer");
            spChantingCount--;
        }
        if (popup == 1) {
            showVideoPopup(view);

            Log.e("MainActivity", "Successfully Video MediaPlayer");
            popup = 0;
        }

        Log.e("MainActivity", "Successfully stop started MediaPlayer");

        stopResetPressed = 1;
        stopwatchRunning = false;
    }

    public void startbutton(View view) {

        startimg.setVisibility(View.INVISIBLE);
        startTime = SystemClock.uptimeMillis();
        stopwatchHandler.postDelayed(runnable_stopwatch, 0);
        stop.setVisibility(View.VISIBLE);
        stopResetPressed = 0;
        stopwatchRunning = true;
        vibrate(50);


        if (mediaPlayer != null && mediaPlayer.getCurrentPosition() == 0 && hkm == 0) {
            mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(playbackSpeed));
            mediaPlayer.start();
            waittime = 4030;
            Log.e("MainActivity", "Successfully started MediaPlayer");
            chantingRoundDataEntity = new ChantingRoundDataEntity();
            chantingRoundDataEntity.setRoundNumber(round);
            chantingRoundDataEntity.setStartTime(new Date());
            chantingRoundDataEntity.setRowId(new UUID().toString());
            handler.postDelayed(runnable_pacnhtattva, (long) (6435 / playbackSpeed));
        } else if (hkm == 1) {
            waittime = 4030;
            updateStartButtonText();
            Log.e("MainActivity", "Failed to initialize MediaPlayer");
        }
    }
    public void resetbutton(View view) {
        stop.setVisibility(View.INVISIBLE);
        startimg.setVisibility(View.VISIBLE);
        vibrate(50);
        goldenview.setVisibility(View.INVISIBLE);
        prog_pos = -1;
        prog_pos2 = -1;

        progressStatus = 0;
        hearprogress = 0;
        horizontalProgressBar2 = prog_bar2[0];
        horizontalProgressBar = prog_bar[0];
        elsec = 0;
        for(int i = 0; i<7;i++){
            prog_bar[i].setProgress(0);
            prog_bar2[i].setSecondaryProgress(0);
        }

        // Reset MediaPlayer
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.sp_hkm);
        }

        // Reset variables
        millisecondTime = 0L;
        startTime = 0L;
        timeBuff = 0L;
        hkm = 0;
        total_time = "00:00";
        handler.removeCallbacks(update_Runnable);
        stopwatchHandler.removeCallbacks(runnable_stopwatch);
        stopwatchRunning = false;
        updateTime = 0L;
        seconds = 0;
        minutes = 0;
        spChantingCount = -1;
        milliSeconds = 0;
        hearingCount = 0;

        // Update UI
        hear_button.setText(String.valueOf(hearingCount));
        start.setText(String.valueOf("0"));
        textView.setText("00:00");
    }



    public void showHelpDialog(Context context) {
        // The view parameter is not used in this example, but you can use it if needed.

        // Create an AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("'Play':-press icon to start .\n'Select Level':- Select count to hear in one time.\n'Hearing':-Press to track your Hearing count.\n'Stop':-Press icon to Stop.\n'Reset':-Press icon to reset.\n'Select Speed':-Choose speed to chant along with it.\n'Early Done':- Press icon if you have completed your round early.\nTable:- You can see your progress report of the current day.\nProgress bars:- One bead has divided into 7 milestones (0-16,17-32,32-48.......96-108)\nNote:- if chanting is not syncing with Prabhupada's voice, please press Stop and wait for 2 seconds and start again. ")
                .setTitle("Help")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked OK button
                        dialog.dismiss(); // Dismiss the dialog
                    }
                });

        // Create and show the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle menu item clicks here
        if(action.onOptionsItemSelected(item)){
            return true;

        }
        return super.onOptionsItemSelected(item);
    }
    private static final float MIN_SPEED = 0.5f;
    private static final float MAX_SPEED = 2.0f;

    private final Runnable runnable_pacnhtattva = new Runnable() {
        @Override
        public void run() {
            updateStartButtonText();
            Log.e("MainActivity", "update start button started");
        }
    };
    private  final Runnable run = new Runnable() {
        @Override
        public void run() {
            // Perform tasks after waittime is over
//                        Log.i(TAG, "wait time: " + (long) (waittime / playbackSpeed));

            startButtonTextView.setText(String.valueOf(spChantingCount));
            Log.d(TAG, "Inside Runnable");
            Log.d(TAG, "startButtonTextCount " + spChantingCount);
            progressStatus += 1;
            normalizedProgress = (int) ((progressStatus / (float) maxCount) * 100);
            horizontalProgressBar.setProgress(normalizedProgress);
            spChantingCount++;

            // Continue the loop by posting the delayed task again
        }
    };
    private final Runnable runnable_stopwatch = new Runnable() {
        @Override
        public void run() {
//            Log.i(TAG, "Thread Name 1: " + Thread.currentThread().getName());
            millisecondTime = SystemClock.uptimeMillis() - startTime;
            updateTime = timeBuff + millisecondTime;
            seconds = (int) (updateTime / 1000);
            minutes = seconds / 60;
            seconds = seconds % 60;
            // Update UI
            textView.setText(MessageFormat.format("{0}:{1}", minutes, String.format(Locale.getDefault(), "%02d", seconds)));
            // Schedule the next update
            stopwatchHandler.postDelayed(this, 0);

        }
    };

    //vibrate function code

    private void vibrate(long milliseconds) {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(milliseconds);
        }
    }
    public void showCustomDialog(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.speedslidebar, null);
        builder.setView(dialogView);

        // Get the EditText inside the TextInputLayout


        show = dialogView.findViewById(R.id.speddtext);
        SeekBar seek = dialogView.findViewById(R.id.seekBar);

// Set the range of the SeekBar
        int maxProgress = 100; // Adjust according to your preference
        seek.setMax(maxProgress);

// Set up a listener to handle changes in the SeekBar
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Calculate the playback speed based on the SeekBar progress
                playbackSpeed = MIN_SPEED + (MAX_SPEED - MIN_SPEED) * progress / (float) maxProgress;
                show.setText(String.valueOf(playbackSpeed));

                // Update the playback speed of the MediaPlayer
                mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(playbackSpeed));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Not needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Not needed
            }
        });

        builder.setTitle("Set Speed");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle OK button click
                if (show != null) {
                    userInput = show.getText().toString().trim();
                    if (!userInput.isEmpty()) {
                        try {
                            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                                float playSpeed = Float.parseFloat(userInput);
                                mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(playSpeed));

                                ReadWriteContactDetails read = new ReadWriteContactDetails();
                                read.name = user.getDisplayName();
                                read.round = String.valueOf(round);
                                read.speed = userInput;
                                database.getReference().child("users").child(user.getUid()).setValue(read).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Toast.makeText(getApplicationContext(), "L in Now", Toast.LENGTH_SHORT).show();

                                    }
                                });
                            }
                        } catch (NumberFormatException e) {
                            // Handle the case where the input cannot be parsed to a float
                            Toast.makeText(MainActivity.this, "Invalid input. Please enter a valid number.", Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    } else {
                        // Handle the case where the input is empty
                    }
                }if (mediaPlayer.getCurrentPosition() < 6435) {
                    mediaPlayer.pause();
                    mediaPlayer.seekTo(0);
                    handler.removeCallbacks(runnable_pacnhtattva);
                } else {
                    hkm = 1;
                    mediaPlayer.release();
                    mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.hkm);
//                    handler.removeCallbacks(update_Runnable);
//            handler.removeCallbacks(run);

                    Log.e("MainActivity", "Successfully hkm started MediaPlayer");
                    spChantingCount--;
                }
                // Do something with the input
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle Cancel button click
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public static int generateRandomNumber(int lowerLimit, int upperLimit, List<Integer> usedNumbers) {
        if (lowerLimit > upperLimit) {
            throw new IllegalArgumentException("Lower limit should be less than or equal to upper limit");
        }

        List<Integer> availableNumbers = new ArrayList<>();
        for (int i = lowerLimit; i <= upperLimit; i++) {
            if (!usedNumbers.contains(i)) {
                availableNumbers.add(i);
            }
        }
        Random random = new Random();
        if (availableNumbers.isEmpty()) {
            throw new IllegalStateException("All numbers in the range have been used");
        }

        int randomIndex = random.nextInt(availableNumbers.size());
        int randomNumber = availableNumbers.get(randomIndex);
        usedNumbers.add(randomNumber);

        return randomNumber;
    }


    public void round_finished(View view) {
        // The view parameter is not used in this example, but you can use it if needed.
        vibrate(50);
        spChantingCount = 109;
    }
}
