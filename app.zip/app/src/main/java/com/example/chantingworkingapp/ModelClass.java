package com.example.chantingworkingapp;

public class ModelClass {
    public String time;
    public int heard;

    public ModelClass(String time, int heard) {
        this.time = time;
        this.heard = heard;
    }
}
